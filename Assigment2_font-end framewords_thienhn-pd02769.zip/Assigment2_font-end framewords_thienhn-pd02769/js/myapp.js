var app = angular.module("myapp", ['ngRoute', 'ngCookies']);

app.config(function($routeProvider) {
    $routeProvider
        .when('/', {
            templateUrl: 'subjects.html'

        })
        .when('/subjects', {
            templateUrl: 'subjects.html'
        })
        .when('/quiz/:id/:name', {
            templateUrl: 'quizaap.html',
            controller: 'quizCtrl'
        })
        .when('/login', {
            templateUrl: 'login.html',
            controller: 'loginctrl'
        })
        .when('/signup', {
            templateUrl: 'signup.html',
            controller: 'signupctrl'
        })

    .when('/forgotpass', {
        templateUrl: 'forgotpassword.html',
        controller: 'forgotctrl'
    })

});




app.controller("quizCtrl", function($scope, $http, $routeParams, quizFactory) {
    $http.get('db/Quizs/' + $routeParams.id + '.js').then(function(res) {
        quizFactory.questions = res.data;
    })
});
app.controller("myctrl", function() {

    // $scope.session = Session;

})


app.controller("signupctrl", function($scope, $http) {
        $scope.addstudent = function() {
            if ($scope.username != null && $scope.password != null && $scope.email != null && $scope.fullname != null) {
                $http.post('http://localhost:3000/student', {
                    username: $scope.username,
                    password: $scope.password,
                    fullname: $scope.fullname,
                    email: $scope.email,
                    gender: $scope.gender,
                    birthday: $scope.birthday,
                    schoolfee: $scope.schoolfee,
                    mark: $scope.mark
                }).then(function(reponse) {
                    alert("Đăng ký thành công");
                    window.location.href = "/dangnhap.html#!login";
                }).catch(function(error) {
                    alert("Đăng ký thất bại");
                })
            } else {
                alert('Vui lòng nhập đầy đủ thông tin * !')

            }

        }


    })
    // app.controller("cook", function($scope, $cookies) {
    //     $scope.myCookiesVal = $cookies.get('cookie');
    //     $scope.setCookies = function(val) {
    //         $cookies.put('cookie', val);
    //     }

// })
app.controller("loginctrl", function($scope, $http, $cookies) {
        $scope.myCookiesVal = $cookies.get('cookie');
        $scope.myCookiesVal1 = $cookies.get('cookiee');
        if ($scope.myCookiesVal == null) {
            $scope.loginOver = true;
        }
        $http.get('http://localhost:3000/student').then(function(res) {
            $scope.sinhvien = res.data;
            $scope.login = function(val, vall) {
                for (var i = 0; i < $scope.sinhvien.length; i++) {
                    if ($scope.username != null && $scope.password != null) {
                        if ($scope.username == $scope.sinhvien[i].username && $scope.password == $scope.sinhvien[i].password) {
                            var name = $scope.sinhvien[i].fullname;
                            alert('Chúc mừng tài khoản ' + name + ' đã đăng nhập thành công!')
                            window.location.href = "index.html";
                        }

                    }


                }
                $cookies.put('cookiee', vall);
                $cookies.put('cookie', val);
                $scope.loginOver = false;

            };
            for (var i = 0; i < $scope.sinhvien.length; i++) {
                if ($scope.myCookiesVal == $scope.sinhvien[i].username && $scope.myCookiesVal1 == $scope.sinhvien[i].password) {
                    $scope.username = $scope.sinhvien[i].username;
                    $scope.password = $scope.sinhvien[i].password;
                    $scope.fullname = $scope.sinhvien[i].fullname;
                    $scope.email = $scope.sinhvien[i].email;
                    $scope.gender = $scope.sinhvien[i].gender;
                    $scope.birthday = $scope.sinhvien[i].birthday;
                    $scope.schoolfee = $scope.sinhvien[i].schoolfee;
                    $scope.id = $scope.sinhvien[i].id;
                };
            };
            $scope.editUser = function(id) {
                $http.put('http://localhost:3000/student/' + id, {
                    username: $scope.username,
                    password: $scope.password,
                    fullname: $scope.fullname,
                    email: $scope.email,
                    gender: $scope.gender,
                    birthday: $scope.birthday,
                    schoolfee: $scope.schoolfee,
                    id: $scope.id
                }).then(function(reponse) {
                    alert("Cập nhật thành công");
                }).catch(function(error) {
                    alert("Cập nhật thất bại");
                })

            }
            $scope.editpass = function(id, vall) {
                for (var i = 0; i < $scope.sinhvien.length; i++) {
                    if ($scope.username == $scope.sinhvien[i].username && $scope.password1 == $scope.sinhvien[i].password && $scope.email == $scope.sinhvien[i].email) {
                        $http.put('http://localhost:3000/student/' + id, {
                            username: $scope.username,
                            password: $scope.password2,
                            fullname: $scope.fullname,
                            email: $scope.email,
                            gender: $scope.gender,
                            birthday: $scope.birthday,
                            schoolfee: $scope.schoolfee,
                            id: $scope.id
                        }).then(function(reponse) {
                            alert("Đổi mật khẩu thành công");
                            window.location.href = "index.html";
                        }).catch(function(error) {
                            alert("Đổi mật khẩu thành công");
                        })
                    }
                }
                $cookies.put('cookiee', vall);
            }
        });
        $scope.logout = function() {
            $cookies.remove('cookie');
            $cookies.remove('cookiee');
            alert("Đăng xuất thành công");
            window.location.href = "/dangnhap.html#!login";

        }



    })
    // app.controller("myUser", function($scope, $http, loginctr) {
    //     $scope.myCookiesVal = $cookies.get('cookie');
    //     $scope.myCookiesVal1 = $cookies.get('cookiee');
    //     $http.get('http://localhost:3000/student').then(function(ress) {
    //         $scope.sinhvien = ress.data;
    //         for (var i = 0; i < $scope.sinhvien.length; i++) {
    //             if ($scope.myCookiesVal == $scope.sinhvien[i].username && $scope.myCookiesVal1 == $scope.sinhvien[i].password) {
    //                 $scope.name = $scope.sinhvien[i].username;
    //                 $scope.password = $scope.sinhvien[i].password;
    //                 $scope.fullname = $scope.sinhvien[i].fullname;
    //                 $scope.email = $scope.sinhvien[i].email;
    //                 $scope.gender = $scope.sinhvien[i].gender;
    //                 $scope.birthday = $scope.sinhvien[i].birthday;
    //                 $scope.schoolfee = $scope.sinhvien[i].schoolfee;
    //             };
    //         };
    //     });

// })

// app.run(function(Session) {}); //bootstrap session;

// app.factory('Session', function($http) {
//     var Session = {
//         data: {},
//         saveSession: function() { /* save session data to db */ },
//         updateSession: function() {
//             /* load data from db */
//             $http.get('http://localhost:3000/student')
//                 .then(function(r) { return Session.data = r.data; })
//         }
//     };
//     Session.updateSession();
//     return Session;
// });
// app.controller("edit", function($scope, http) {
//     $http.get('http://localhost:3000/student').then(function(resss) {
//         $scope.sinhvien = resss.data;
//         $scope.editUser = function(id) {
//             for (var i = 0; i < $scope.sinhvien.length; i++) {
//                 if (id == $scope.sinhvien[i].id) {
//                     $http.put('http://localhost:3000/student', {
//                         username: $scope.username,
//                         password: $scope.password,
//                         fullname: $scope.fullname,
//                         email: $scope.email,
//                         gender: $scope.gender,
//                         birthday: $scope.birthday,
//                         schoolfee: $scope.schoolfee,
//                         mark: $scope.mark
//                     }).then(function(reponse) {
//                         alert("Cập nhật thành công");
//                     }).catch(function(error) {
//                         alert("Cập nhật thất bại");
//                     })
//                 }
//             }



//         }
//     })
// });
app.controller("forgotctrl", function($scope, $http) {

    $http.get('http://localhost:3000/student').then(function(ress) {
        $scope.sinhvien = ress.data;
        $scope.forgot = function() {
            for (var i = 0; i < $scope.sinhvien.length; i++) {
                if ($scope.username !== "" && $scope.email !== "") {
                    if ($scope.username == $scope.sinhvien[i].username && $scope.email == $scope.sinhvien[i].email) {
                        var matkhau = $scope.sinhvien[i].password;
                        var name = $scope.sinhvien[i].username;
                        alert(' Mật Khẩu của tài khoản ' + name + ' là ' + matkhau);
                        //  alert(["Mật Khẩu :", matkhau]);
                    }

                }

            }
        }
    })

})


app.controller("subjnectsCtrl", function($scope, $http) {
    $scope.list_subjnects = [];
    $http.get('db/Subjects.js').then(function(reponse) {
        $scope.list_subjnects = reponse.data;
        $scope.begin = 0;
        $scope.pageCount = Math.ceil($scope.list_subjnects.length / 4);
        $scope.first = function() {
            $scope.begin = 0;
        };
        $scope.prev = function() {
            if ($scope.begin > 0) {
                $scope.begin -= 4;
            }
        };
        $scope.next = function() {
            if ($scope.begin < ($scope.pageCount - 1) * 4) {
                $scope.begin += 4;
            }
        };
        $scope.last = function() {
            $scope.begin = ($scope.pageCount - 1) * 4;
        };
    })

});


app.directive("quiz", function(quizFactory, $routeParams) {
    return {
        restrict: 'AE',
        scope: {},
        templateUrl: "templateQuiz.html",
        link: function(scope, elem, attrs) {

            scope.start = function() {
                quizFactory.getQuestions().then(function() {
                    scope.subjnectsName = $routeParams.name;

                    scope.id = 0;
                    scope.scoref = 1;
                    scope.imProgess = true;
                    scope.quizOver = false;
                    scope.getQuestion();

                });
                var h = 0; // Giờ
                var m = 0; // Phút
                var s = 10; // Giây
                var timeout = null; // Timeout

                $(document).ready(function start() {
                    if (s === -1) {
                        m -= 1;
                        s = 59;
                    }
                    if (m === -1) {
                        h -= 1;
                        m = 59;

                    }
                    if (h == -1) {
                        clearTimeout(timeout);
                        alert('Hết giờ');
                        scope.quizOver = true;
                        return false;
                    }
                    document.getElementById('h').innerText = h.toString();
                    document.getElementById('m').innerText = m.toString();
                    document.getElementById('s').innerText = s.toString();
                    timeout = setTimeout(function() {
                        s--;
                        start();
                    }, 1000);

                });


            };
            scope.reset = function() {
                scope.subjnectsName = $routeParams.name;
                scope.imProgess = false;
                scope.score = 0;
            };
            scope.getQuestion = function() {
                var quiz = quizFactory.getQuestion(scope.id);
                if (quiz) {
                    scope.question = quiz.Text;
                    scope.options = quiz.Answers;
                    scope.answer = quiz.AnswerId;
                    scope.answerMode = true;
                } else {
                    scope.quizOver = true;
                }


            };
            scope.checkAnswer = function() {
                if (!$('input[name=answer]:checked').length) return;
                var ans = $('input[name=answer]:checked').val();
                if (ans == scope.answer) {

                    scope.score++;
                    scope.correctAns = true;
                } else {

                    scope.correctAns = false;
                }
                scope.answerMode = false;
            }
            scope.nextQuestion = function() {
                scope.id++;
                scope.scoref++;
                scope.getQuestion();
            };
            scope.reset();
        }
    }
});
app.factory("quizFactory", function($http, $routeParams) {

    return {
        getQuestions: function() {
            return $http.get('db/Quizs/' + $routeParams.id + '.js').then(function(res) {
                questions = res.data;

            });
        },
        getQuestion: function(id) {
            var ramdomQ = questions[Math.floor(Math.random() * questions.length)];
            var count = questions.length;
            if (count > 10) {
                count = 10;
            };

            if (id < count) {
                return ramdomQ;
            } else {
                return false;
            }

        }
    }
});